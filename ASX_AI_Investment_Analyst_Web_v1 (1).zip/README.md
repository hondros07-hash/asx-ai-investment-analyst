# ASX AI Investment Analyst — Web App

This is a browser-based Streamlit prototype. It accepts any ASX ticker and displays market data, fundamentals, valuation fields and technical indicators.

## Deploy free with Streamlit Community Cloud

1. Create/sign in to GitHub.
2. Create a new repository named `asx-ai-investment-analyst`.
3. Upload `app.py`, `requirements.txt`, and this README.
4. Open Streamlit Community Cloud: https://share.streamlit.io/
5. Connect GitHub.
6. Choose your repository, branch `main`, and `app.py`.
7. Deploy.
8. Your app will receive a `streamlit.app` URL.

## Next production layer

Connect:
- licensed ASX market/reference data
- ASX announcements and company reports
- an LLM API
- persistent watchlists / portfolio
- bull/base/bear valuation engine
- sector-specific analysis
- thesis tracking
- alerts

The prototype intentionally does not pretend that those pieces are already connected.
